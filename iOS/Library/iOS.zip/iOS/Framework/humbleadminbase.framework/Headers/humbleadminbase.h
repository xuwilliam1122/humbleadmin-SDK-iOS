//
//  humbleadminbase.h
//  humbleadminbase
//
//  Created by HRWY on 15/11/3.
//  Copyright © 2015年 HRWY. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <humbleadminbase/HABTrustyIDLogin.h>

@interface humbleadminbase : NSObject

@end